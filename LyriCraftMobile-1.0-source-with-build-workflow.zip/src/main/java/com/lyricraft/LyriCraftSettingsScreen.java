package com.lyricraft;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class LyriCraftSettingsScreen extends Screen {
    public static boolean previewEnabled = true;

    public LyriCraftSettingsScreen() {
        super(Component.literal("LyriCraft Mobile"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        this.addRenderableWidget(Button.builder(
                Component.literal("HUD preview: " + (previewEnabled ? "ON" : "OFF")),
                button -> {
                    previewEnabled = !previewEnabled;
                    button.setMessage(Component.literal("HUD preview: " + (previewEnabled ? "ON" : "OFF")));
                }
        ).bounds(centerX - 100, centerY - 10, 200, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Close"),
                button -> this.onClose()
        ).bounds(centerX - 100, centerY + 20, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 55, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font,
                Component.literal("Starter build: music sync is not connected yet."),
                this.width / 2, this.height / 2 - 32, 0xFFCCCCCC);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
