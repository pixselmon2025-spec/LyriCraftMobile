package com.lyricraft;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class LyriCraftClient implements ClientModInitializer {
    public static final String MOD_ID = "lyricraft";
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "controls")
        );

        // Default shortcut: Ctrl + B. The game key mapping is B; Ctrl is checked below.
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.lyricraft.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null && client.getWindow().getWindow() != 0L) {
                    long window = client.getWindow().getWindow();
                    boolean ctrlDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                            || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
                    if (ctrlDown) {
                        client.setScreen(new LyriCraftSettingsScreen());
                    }
                }
            }
        });

        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(MOD_ID, "lyrics_hud"),
                (graphics, deltaTracker) -> {
                    Minecraft client = Minecraft.getInstance();
                    if (client.player != null && client.options.hideGui == false) {
                        String lyric = LyriCraftSettingsScreen.previewEnabled
                                ? "♪ LyriCraft — connect a music source to show lyrics ♪"
                                : "";
                        if (!lyric.isEmpty()) {
                            graphics.drawCenteredString(
                                    client.font,
                                    Component.literal(lyric),
                                    client.getWindow().getGuiScaledWidth() / 2,
                                    client.getWindow().getGuiScaledHeight() - 48,
                                    0xFFE8F5FF
                            );
                        }
                    }
                }
        );
    }
}
