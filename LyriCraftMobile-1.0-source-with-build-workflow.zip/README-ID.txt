LyriCraft Mobile — starter source project
Target: Minecraft Java 1.21.11 / Fabric / Java 21

Isi build awal:
- Client-only Fabric mod.
- HUD preview sederhana.
- Menu pengaturan dibuka dengan Ctrl+B (key B + pemeriksaan Ctrl).
- Belum ada integrasi Spotify/YouTube, pengambilan lirik, atau aplikasi pendamping Android.
- Belum diuji pada MJ Launcher; kompatibilitas Android perlu diuji di perangkatmu.

Cara build di PC:
1. Pasang JDK 21 dan Gradle.
2. Buka folder proyek ini di IntelliJ IDEA atau terminal.
3. Jalankan: gradle build
4. Ambil JAR dari build/libs/.

Catatan:
Fabric API 0.141.1+1.21.11 dan Loader 0.18.1 mengikuti referensi Fabric 1.21.11.
Loom 1.14-SNAPSHOT digunakan untuk target Minecraft 1.21.11.
